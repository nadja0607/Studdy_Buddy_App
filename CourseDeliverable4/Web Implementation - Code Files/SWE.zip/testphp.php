
<?php

	echo "Text PHP";
?>

